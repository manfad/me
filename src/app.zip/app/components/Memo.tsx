
interface MemoProps {
  title?: string;
  rotation?: number;
  position?: { x: number; y: number };
  children?: React.ReactNode;
  size?:{width:number; height:number }
}

export function Memo({children, title = '', rotation = -5,size = { width:250, height:180}, position = { x: 200, y: 400 } }: MemoProps) {

  return (
    <div
      className="relative bg-yellow-100 shadow-lg border border-yellow-200 p-4"
      style={{
        width: '100%',
        maxWidth: `${size.width}px`,
        aspectRatio: 2 / 1, 
        transform: `rotate(${rotation}deg)`,
        left: `${position.x}px`,
        top: `${position.y}px`,
      }}
    >
      <div className="text-center text-sm mb-2 font-semibold">{title}</div>
      {children}
    </div>
  );
}
