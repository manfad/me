interface PaperProps {
  children: React.ReactNode;
}

export default function Paper({ children }: PaperProps) {
  return (
    <div
  className="w-90 min-h-[650px] bg-white rounded-sm relative p-4 sm:p-8 sm:pr-10 sm:pl-6 sm:pt-8"
  style={{
    boxShadow:
      '0 2px 5px rgba(0,0,0,0.1), 0 10px 30px rgba(0,0,0,0.4), inset 0 0 100px rgba(101, 67, 33, 0.08)',
  }}
>
  {/* Line pattern */}
  <div
    className="absolute top-8 left-3 right-3 bottom-0 pointer-events-none z-0"
    style={{
      backgroundImage: `repeating-linear-gradient(
        transparent,
        transparent 1.8em, /* matches text line-height */
        rgba(150, 130, 110, 0.35) 1.8em,
        rgba(150, 130, 110, 0.35) calc(1.8em + 1px)
      )`,
    }}
  />

 
  {/* Text content */}
  <div
    className="relative z-10 text-[#1a1a1a] text-base sm:text-lg leading-[1.65em]"
    style={{ wordWrap: 'break-word' }}
  >
    {children}
  </div>
</div>

  )
}